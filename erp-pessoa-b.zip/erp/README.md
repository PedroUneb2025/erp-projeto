# ERP — entregas da Pessoa B (RH, Vendas/CRM, Serviços, Portais, HA)

## Subir o ambiente
```bash
cp .env.example .env
docker compose up -d --build           # Postgres primário+réplica, HAProxy, Flyway (migra), API, front
docker compose run --rm seed           # dados de exemplo (uma vez)
# API: http://localhost:8000/docs  ·  Front: http://localhost:5173
# Logins (senha123): admin@erp.local · cliente@erp.local · fornecedor@erp.local · colab@erp.local
docker compose exec api pytest         # testes (usa DATABASE_WRITE_URL do container)
```
`V1__core_stub.sql` é um **stub** do schema `core` da Pessoa A (contrato descrito no topo do arquivo): substitua pela migração oficial e ajuste `db/seeds/seed.sql`.

## Mapa do checklist
| Item | Onde |
|---|---|
| ER (DbSchema) | `docs/er.md` (Mermaid; reproduzir no DbSchema) |
| Migrações Flyway | `db/migrations` (V9 auditoria, V10–13 RH, V20–22 SD, V30 SM, V40 índices) |
| Trigger/procedure/function/2 views/sequence por módulo | `docs/rh.md`, `docs/sd.md`, `docs/sm.md` |
| Endpoints e telas admin | `backend/app/{rh,sd,sm}`, `frontend/src/admin` |
| Mobile e Portal Web | `frontend/src/portais` (React + Tailwind responsivo; login por perfil) |
| Seeds e pytest | `db/seeds/seed.sql`, `backend/tests` |
| Modelo físico | `docs/modelo_fisico.md`, `scripts/export_ddl.sh` |
| Réplica, backup, balanceamento, RPO/RTO | `docker-compose.yml`, `db/ha`, `docs/alta_disponibilidade.md` |
