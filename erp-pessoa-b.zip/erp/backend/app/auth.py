import os
import time

import jwt
from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel

from .db import rodar, write_pool

SECRET = os.getenv("JWT_SECRET", "dev-secret-troque-em-producao")
router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


class Login(BaseModel):
    email: str
    senha: str


def criar_token(u: dict) -> str:
    payload = {
        "sub": str(u["id"]), "perfil": u["perfil"],
        "cliente_id": u["cliente_id"], "fornecedor_id": u["fornecedor_id"], "colaborador_id": u["colaborador_id"],
        "exp": int(time.time()) + 8 * 3600,
    }
    return jwt.encode(payload, SECRET, algorithm="HS256")


def current_user(authorization: str = Header(None)) -> dict:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Token ausente")
    try:
        return jwt.decode(authorization[7:], SECRET, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise HTTPException(401, "Token inválido ou expirado")


def somente_admin(u: dict = Depends(current_user)) -> dict:
    if u["perfil"] != "admin":
        raise HTTPException(403, "Apenas administradores")
    return u


@router.post("/login")
def login(dados: Login):
    rows = rodar(write_pool,
                 "select id, perfil, cliente_id, fornecedor_id, colaborador_id from core.usuarios "
                 "where email = %s and senha_hash = crypt(%s, senha_hash) and deleted_at is null",
                 (dados.email, dados.senha))
    if not rows:
        raise HTTPException(401, "Credenciais inválidas")
    return {"access_token": criar_token(rows[0]), "perfil": rows[0]["perfil"]}
