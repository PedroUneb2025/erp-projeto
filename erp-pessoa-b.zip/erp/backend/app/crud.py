"""CRUD genérico por tabela: GET/POST /<tabela>, GET/PATCH/DELETE /<tabela>/{id}.
Exclusão é lógica (deleted_at). Perfis não-admin só enxergam as próprias linhas (campo 'escopo')."""
from fastapi import APIRouter, Depends, HTTPException, Request
from psycopg import sql

from .auth import current_user, somente_admin
from .db import read_pool, rodar, write_pool


def escopo(cfg: dict, u: dict):
    """None para admin; (coluna, valor) para quem só vê as próprias linhas; 403 caso contrário."""
    if u["perfil"] == "admin":
        return None
    col = cfg.get("escopo", {}).get(u["perfil"])
    if not col or u.get(col) is None:
        raise HTTPException(403, "Perfil sem acesso a este recurso")
    return col, u[col]


def _registrar(r: APIRouter, schema: str, nome: str, cfg: dict):
    tbl, cols = sql.Identifier(schema, nome), cfg["cols"]

    @r.get(f"/{nome}", name=f"listar_{nome}")
    def listar(request: Request, limite: int = 100, deslocamento: int = 0, u: dict = Depends(current_user)):
        filtros = {k: v for k, v in request.query_params.items() if k in cols}
        if (e := escopo(cfg, u)):
            filtros[e[0]] = e[1]
        where = [sql.SQL("deleted_at is null")] + [sql.SQL("{} = %s").format(sql.Identifier(k)) for k in filtros]
        q = sql.SQL("select * from {} where {} order by id desc limit %s offset %s").format(tbl, sql.SQL(" and ").join(where))
        return rodar(read_pool, q, [*filtros.values(), min(limite, 500), deslocamento])

    @r.get(f"/{nome}/{{item_id}}", name=f"obter_{nome}")
    def obter(item_id: int, u: dict = Depends(current_user)):
        params, where = [item_id], [sql.SQL("id = %s"), sql.SQL("deleted_at is null")]
        if (e := escopo(cfg, u)):
            where.append(sql.SQL("{} = %s").format(sql.Identifier(e[0])))
            params.append(e[1])
        rows = rodar(read_pool, sql.SQL("select * from {} where {}").format(tbl, sql.SQL(" and ").join(where)), params)
        if not rows:
            raise HTTPException(404, "Não encontrado")
        return rows[0]

    @r.post(f"/{nome}", status_code=201, name=f"criar_{nome}")
    def criar(dados: dict, u: dict = Depends(current_user)):
        admin = u["perfil"] == "admin"
        if not admin and u["perfil"] not in cfg.get("criar", ()):
            raise HTTPException(403, "Sem permissão de criação")
        permitidas = cols if admin else cfg.get("cols_publicas", [])
        d = {k: v for k, v in dados.items() if k in permitidas}
        if (e := escopo(cfg, u)):
            d[e[0]] = e[1]
        d["created_by"] = int(u["sub"])
        q = sql.SQL("insert into {} ({}) values ({}) returning *").format(
            tbl, sql.SQL(", ").join(map(sql.Identifier, d)), sql.SQL(", ").join(sql.Placeholder() * len(d)))
        return rodar(write_pool, q, list(d.values()), u["sub"])[0]

    @r.patch(f"/{nome}/{{item_id}}", name=f"atualizar_{nome}")
    def atualizar(item_id: int, dados: dict, u: dict = Depends(somente_admin)):
        d = {k: v for k, v in dados.items() if k in cols}
        if not d:
            raise HTTPException(400, "Nenhum campo válido")
        q = sql.SQL("update {} set {} where id = %s and deleted_at is null returning *").format(
            tbl, sql.SQL(", ").join(sql.SQL("{} = %s").format(sql.Identifier(k)) for k in d))
        rows = rodar(write_pool, q, [*d.values(), item_id], u["sub"])
        if not rows:
            raise HTTPException(404, "Não encontrado")
        return rows[0]

    @r.delete(f"/{nome}/{{item_id}}", status_code=204, name=f"excluir_{nome}")
    def excluir(item_id: int, u: dict = Depends(somente_admin)):
        q = sql.SQL("update {} set deleted_at = now() where id = %s and deleted_at is null returning id").format(tbl)
        if not rodar(write_pool, q, [item_id], u["sub"]):
            raise HTTPException(404, "Não encontrado")


def crud_router(modulo: str, schema: str, tabelas: dict) -> APIRouter:
    r = APIRouter(prefix=f"/api/v1/{modulo}", tags=[modulo])
    for nome, cfg in tabelas.items():
        _registrar(r, schema, nome, cfg)
    return r
