import os
from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

WRITE_URL = os.getenv("DATABASE_WRITE_URL", "postgresql://erp:erp123@localhost:5000/erp")
READ_URL = os.getenv("DATABASE_READ_URL", WRITE_URL)  # leitura vai para a réplica via HAProxy

write_pool = ConnectionPool(WRITE_URL, min_size=1, max_size=10, open=False)
read_pool = ConnectionPool(READ_URL, min_size=1, max_size=10, open=False)


def rodar(pool, query, params=None, user_id=None):
    """Executa uma consulta numa transação; devolve lista de dicts (se houver resultado).
    user_id alimenta audit.fn_usuario_atual() para a auditoria no banco."""
    with pool.connection() as conn:
        if user_id is not None:
            conn.execute("select set_config('app.user_id', %s, true)", (str(user_id),))
        cur = conn.cursor(row_factory=dict_row)
        cur.execute(query, params)
        return cur.fetchall() if cur.description else []
