from contextlib import asynccontextmanager

from fastapi import FastAPI

from . import auth
from .db import read_pool, write_pool
from .rh import router as rh_router
from .sd import router as sd_router
from .sm import router as sm_router


@asynccontextmanager
async def lifespan(_: FastAPI):
    write_pool.open()
    read_pool.open()
    yield
    write_pool.close()
    read_pool.close()


app = FastAPI(title="ERP - RH, Vendas/CRM e Serviços", lifespan=lifespan)
for r in (auth.router, rh_router, sd_router, sm_router):
    app.include_router(r)


@app.get("/api/v1/saude")
def saude():
    return {"status": "ok"}
