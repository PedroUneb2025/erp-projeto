from datetime import date

from fastapi import Depends

from ..auth import current_user, somente_admin
from ..crud import crud_router, escopo
from ..db import read_pool, rodar, write_pool

COL = {"colaborador": "colaborador_id"}
TABELAS = {
    "dados_colaboradores": {"cols": ["colaborador_id", "cpf", "data_nascimento", "data_admissao"], "escopo": COL},
    "cargos": {"cols": ["nome", "descricao", "salario_base_ref"]},
    "colaboradores_cargos": {"cols": ["colaborador_id", "cargo_id", "salario_base", "inicio", "fim"]},
    "beneficios": {"cols": ["nome", "valor"]},
    "colaboradores_beneficios": {"cols": ["colaborador_id", "beneficio_id", "inicio", "fim"]},
    "folhas_pagamento": {"cols": ["colaborador_id", "competencia", "salario_base", "liquido"], "escopo": COL},
    "registros_ponto": {"cols": ["colaborador_id", "registrado_em", "tipo"], "escopo": COL,
                        "criar": ["colaborador"], "cols_publicas": ["tipo"]},
    "vagas": {"cols": ["titulo", "cargo_id", "status", "aberta_em"]},
    "candidatos": {"cols": ["vaga_id", "nome", "email", "status"]},
    "avaliacoes_desempenho": {"cols": ["colaborador_id", "avaliador_id", "periodo", "nota", "comentarios"], "escopo": COL},
}
router = crud_router("rh", "rh", TABELAS)


@router.post("/folha/gerar")
def gerar_folha(competencia: date, u: dict = Depends(somente_admin)):
    """Procedure rh.sp_gerar_folha: gera a folha do mês para todos os colaboradores vigentes."""
    row = rodar(write_pool, "call rh.sp_gerar_folha(%s, 0)", (competencia,), u["sub"])[0]
    return {"competencia": competencia, "gerados": row["p_gerados"]}


@router.get("/folha/calcular/{colaborador_id}")
def calcular_folha(colaborador_id: int, competencia: date, u: dict = Depends(somente_admin)):
    """Function rh.fn_calcular_folha."""
    row = rodar(read_pool, "select rh.fn_calcular_folha(%s, %s) as liquido", (colaborador_id, competencia))[0]
    return {"colaborador_id": colaborador_id, "competencia": competencia, "liquido": row["liquido"]}


@router.get("/views/banco_horas")
def banco_horas(u: dict = Depends(current_user)):
    e = escopo({"escopo": COL}, u)
    q = "select * from rh.vw_banco_horas" + (" where colaborador_id = %s" if e else "") + " order by competencia desc"
    return rodar(read_pool, q, [e[1]] if e else None)


@router.get("/views/folha_resumo")
def folha_resumo(u: dict = Depends(somente_admin)):
    return rodar(read_pool, "select * from rh.vw_folha_resumo")
