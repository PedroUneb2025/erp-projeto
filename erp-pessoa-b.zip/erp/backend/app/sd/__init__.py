from fastapi import Depends, HTTPException

from ..auth import somente_admin
from ..crud import crud_router
from ..db import read_pool, rodar, write_pool

CLI = {"cliente": "cliente_id"}
TABELAS = {
    "pedidos": {"cols": ["cliente_id", "status", "observacao"], "escopo": CLI},
    "pedidos_itens": {"cols": ["pedido_id", "descricao", "quantidade", "preco_unitario"]},
    "contratos": {"cols": ["cliente_id", "objeto", "valor_mensal", "inicio", "fim", "status"], "escopo": CLI},
    "faturas": {"cols": ["pedido_id", "cliente_id", "valor", "vencimento", "status"], "escopo": CLI},
    "etapas_funil": {"cols": ["nome", "ordem"]},
    "oportunidades": {"cols": ["cliente_id", "etapa_id", "titulo", "valor_estimado", "probabilidade",
                               "responsavel_id", "fechamento_previsto"]},
    "interacoes": {"cols": ["cliente_id", "oportunidade_id", "canal", "resumo", "ocorrida_em"]},
}
router = crud_router("sd", "sd", TABELAS)


@router.post("/pedidos/{pedido_id}/faturar")
def faturar(pedido_id: int, u: dict = Depends(somente_admin)):
    """Procedure sd.sp_faturar_pedido."""
    try:
        row = rodar(write_pool, "call sd.sp_faturar_pedido(%s, null::bigint)", (pedido_id,), u["sub"])[0]
    except Exception as exc:  # regras de negócio levantam RAISE EXCEPTION no banco
        raise HTTPException(409, str(exc).splitlines()[0])
    return {"pedido_id": pedido_id, "fatura_id": row["p_fatura_id"]}


@router.get("/views/funil_vendas")
def funil(u: dict = Depends(somente_admin)):
    return rodar(read_pool, "select * from sd.vw_funil_vendas")


@router.get("/views/pedidos_abertos")
def pedidos_abertos(u: dict = Depends(somente_admin)):
    return rodar(read_pool, "select * from sd.vw_pedidos_abertos")
