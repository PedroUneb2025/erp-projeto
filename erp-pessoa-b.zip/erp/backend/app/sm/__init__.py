from fastapi import Depends, HTTPException

from ..auth import somente_admin
from ..crud import crud_router
from ..db import read_pool, rodar, write_pool

TABELAS = {
    "contratos_manutencao": {"cols": ["cliente_id", "descricao", "sla_horas", "valor_mensal", "inicio", "fim"],
                             "escopo": {"cliente": "cliente_id"}},
    "ordens_servico": {
        "cols": ["cliente_id", "contrato_id", "fornecedor_id", "tecnico_id", "titulo", "descricao",
                 "prioridade", "status"],
        "escopo": {"cliente": "cliente_id", "fornecedor": "fornecedor_id"},
        "criar": ["cliente"], "cols_publicas": ["titulo", "descricao", "prioridade"],
    },
    "atendimentos": {"cols": ["os_id", "tecnico_id", "descricao", "inicio", "fim"]},
    "agendamentos": {"cols": ["os_id", "tecnico_id", "inicio", "fim"]},
}
router = crud_router("sm", "sm", TABELAS)


@router.post("/ordens_servico/{os_id}/concluir")
def concluir(os_id: int, u: dict = Depends(somente_admin)):
    """Procedure sm.sp_concluir_os."""
    try:
        row = rodar(write_pool, "call sm.sp_concluir_os(%s, null::boolean)", (os_id,), u["sub"])[0]
    except Exception as exc:
        raise HTTPException(409, str(exc).splitlines()[0])
    return {"os_id": os_id, "sla_estourado": row["p_estourou"]}


@router.get("/ordens_servico/{os_id}/sla")
def sla(os_id: int, u: dict = Depends(somente_admin)):
    """Function sm.fn_sla_estourado."""
    return {"os_id": os_id, "sla_estourado": rodar(read_pool, "select sm.fn_sla_estourado(%s) as v", (os_id,))[0]["v"]}


@router.get("/views/os_em_atraso")
def os_em_atraso(u: dict = Depends(somente_admin)):
    return rodar(read_pool, "select * from sm.vw_os_em_atraso order by horas_atraso desc")


@router.get("/views/agenda_tecnicos")
def agenda(u: dict = Depends(somente_admin)):
    return rodar(read_pool, "select * from sm.vw_agenda_tecnicos order by inicio")
