"""Testes de integração: exigem o banco do Compose migrado e com seeds (DATABASE_WRITE_URL definido)."""
import os

import psycopg
import pytest
from fastapi.testclient import TestClient

from app.main import app

pytestmark = pytest.mark.skipif(not os.getenv("DATABASE_WRITE_URL"), reason="sem banco de dados")


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def auth(client, email):
    r = client.post("/api/v1/auth/login", json={"email": email, "senha": "senha123"})
    assert r.status_code == 200
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def test_login_invalido(client):
    assert client.post("/api/v1/auth/login", json={"email": "admin@erp.local", "senha": "x"}).status_code == 401


def test_admin_lista_cargos(client):
    r = client.get("/api/v1/rh/cargos", headers=auth(client, "admin@erp.local"))
    assert r.status_code == 200 and len(r.json()) >= 3


def test_cliente_nao_acessa_rh_e_ve_so_seus_pedidos(client):
    h = auth(client, "cliente@erp.local")
    assert client.get("/api/v1/rh/cargos", headers=h).status_code == 403
    pedidos = client.get("/api/v1/sd/pedidos", headers=h).json()
    assert pedidos and all(p["cliente_id"] == 1 for p in pedidos)


def test_trigger_recalcula_total_do_pedido(client):
    h = auth(client, "admin@erp.local")
    p = client.post("/api/v1/sd/pedidos", json={"cliente_id": 2}, headers=h).json()
    client.post("/api/v1/sd/pedidos_itens", json={"pedido_id": p["id"], "descricao": "X", "quantidade": 2, "preco_unitario": 10.5}, headers=h)
    assert float(client.get(f"/api/v1/sd/pedidos/{p['id']}", headers=h).json()["total"]) == 21.0


def test_faturar_pedido_aprovado(client):
    h = auth(client, "admin@erp.local")
    p = client.post("/api/v1/sd/pedidos", json={"cliente_id": 1, "status": "aprovado"}, headers=h).json()
    client.post("/api/v1/sd/pedidos_itens", json={"pedido_id": p["id"], "descricao": "Y", "quantidade": 1, "preco_unitario": 99}, headers=h)
    r = client.post(f"/api/v1/sd/pedidos/{p['id']}/faturar", headers=h)
    assert r.status_code == 200 and r.json()["fatura_id"]
    assert client.post(f"/api/v1/sd/pedidos/{p['id']}/faturar", headers=h).status_code == 409  # já faturado


def test_sla_calculado_na_abertura_e_os_atrasada(client):
    h = auth(client, "cliente@erp.local")
    os_ = client.post("/api/v1/sm/ordens_servico", json={"titulo": "Teste", "prioridade": "alta", "status": "concluida"}, headers=h).json()
    assert os_["prazo_sla"] and os_["status"] == "aberta"  # status não é aceito do cliente
    atrasadas = client.get("/api/v1/sm/views/os_em_atraso", headers=auth(client, "admin@erp.local")).json()
    assert any(o["numero"] for o in atrasadas)


def test_folha_calculada(client):
    r = client.get("/api/v1/rh/folha/calcular/2", params={"competencia": "2026-11-01"}, headers=auth(client, "admin@erp.local"))
    assert float(r.json()["liquido"]) == 3200 + 600 + 350 - 352  # salário + benefícios - 11%


def test_mudanca_de_salario_vai_para_auditoria(client):
    h = auth(client, "admin@erp.local")
    cc = client.get("/api/v1/rh/colaboradores_cargos", params={"colaborador_id": 3}, headers=h).json()[0]
    client.patch(f"/api/v1/rh/colaboradores_cargos/{cc['id']}", json={"salario_base": 5000}, headers=h)
    with psycopg.connect(os.environ["DATABASE_WRITE_URL"]) as c:
        n = c.execute("select count(*) from audit.auditoria where acao='ALTERACAO_SALARIO' and registro_id=%s", (cc["id"],)).fetchone()[0]
    assert n >= 1


def test_colaborador_registra_ponto_so_para_si(client):
    h = auth(client, "colab@erp.local")
    r = client.post("/api/v1/rh/registros_ponto", json={"tipo": "entrada", "colaborador_id": 1}, headers=h)
    assert r.status_code == 201 and r.json()["colaborador_id"] == 2
