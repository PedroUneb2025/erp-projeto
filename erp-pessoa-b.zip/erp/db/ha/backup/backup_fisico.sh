#!/bin/sh
set -e
D=/backups/fisico/base_$(date +%F)
pg_basebackup -h pg-primary -U replicator -D "$D" -Ft -z -X stream
find /backups/fisico -maxdepth 1 -name 'base_*' -mtime +21 -exec rm -rf {} +
echo "$(date -Is) fisico ok: $D"
