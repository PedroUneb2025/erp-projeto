#!/bin/sh
set -e
F=/backups/logico/erp_$(date +%F).dump
pg_dump -h pg-primary -U erp -d erp -Fc -f "$F"
find /backups/logico -name '*.dump' -mtime +7 -delete
echo "$(date -Is) logico ok: $F"
