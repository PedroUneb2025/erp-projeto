#!/bin/sh
mkdir -p /backups/logico /backups/fisico
{ echo "pg-primary:5432:*:erp:${POSTGRES_PASSWORD}"; echo "pg-primary:5432:*:replicator:${REPL_PASSWORD}"; } > /root/.pgpass
chmod 600 /root/.pgpass
cp /backup/crontab /etc/crontabs/root
cp /backup/backup_logico.sh /backup/backup_fisico.sh /usr/local/bin/ && chmod +x /usr/local/bin/backup_*.sh
exec crond -f -l 8
