#!/bin/bash
# Primeira subida: clona o primário (pg_basebackup -R cria standby.signal + primary_conninfo).
set -e
mkdir -p "$PGDATA" && chown postgres:postgres "$PGDATA" && chmod 700 "$PGDATA"
if [ ! -s "$PGDATA/PG_VERSION" ]; then
  until pg_isready -h pg-primary -U erp; do sleep 2; done
  PGPASSWORD="$REPL_PASSWORD" gosu postgres pg_basebackup -h pg-primary -U replicator -D "$PGDATA" -R -X stream -C -S replica1
fi
exec gosu postgres postgres -c hot_standby=on
