create schema rh;
create sequence rh.seq_matricula start 1000;

create table rh.dados_colaboradores (
  id bigint generated always as identity primary key,
  colaborador_id bigint not null unique references core.colaboradores(id),
  matricula bigint not null unique default nextval('rh.seq_matricula'),
  cpf text check (length(cpf) <= 14),
  data_nascimento date,
  data_admissao date not null default current_date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table rh.cargos (
  id bigint generated always as identity primary key,
  nome text not null check (length(nome) <= 120),
  descricao text,
  salario_base_ref numeric(14,2) not null check (salario_base_ref >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table rh.colaboradores_cargos (
  id bigint generated always as identity primary key,
  colaborador_id bigint not null references core.colaboradores(id),
  cargo_id bigint not null references rh.cargos(id),
  salario_base numeric(14,2) not null check (salario_base >= 0),
  inicio date not null default current_date,
  fim date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);

-- Trigger: qualquer mudança de salário vai para a auditoria.
create function rh.fn_auditar_salario() returns trigger language plpgsql as $$
begin
  if new.salario_base is distinct from old.salario_base then
    insert into audit.auditoria (created_by, tabela, registro_id, acao, dados_antigos, dados_novos)
    values (audit.fn_usuario_atual(), 'rh.colaboradores_cargos', old.id, 'ALTERACAO_SALARIO',
            jsonb_build_object('salario_base', old.salario_base),
            jsonb_build_object('salario_base', new.salario_base));
  end if;
  return new;
end $$;
create trigger trg_colaboradores_cargos_salario
  after update on rh.colaboradores_cargos
  for each row execute function rh.fn_auditar_salario();
