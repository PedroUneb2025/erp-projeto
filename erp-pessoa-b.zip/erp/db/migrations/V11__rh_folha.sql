create table rh.beneficios (
  id bigint generated always as identity primary key,
  nome text not null check (length(nome) <= 120),
  valor numeric(14,2) not null check (valor >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table rh.colaboradores_beneficios (
  id bigint generated always as identity primary key,
  colaborador_id bigint not null references core.colaboradores(id),
  beneficio_id bigint not null references rh.beneficios(id),
  inicio date not null default current_date,
  fim date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table rh.folhas_pagamento (
  id bigint generated always as identity primary key,
  colaborador_id bigint not null references core.colaboradores(id),
  competencia date not null check (competencia = date_trunc('month', competencia)::date),
  salario_base numeric(14,2) not null,
  liquido numeric(14,2) not null,
  unique (colaborador_id, competencia),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);

-- Function: salário base + benefícios - descontos simplificados (11% sobre o salário).
create function rh.fn_calcular_folha(p_colaborador_id bigint, p_competencia date)
returns numeric(14,2) language plpgsql stable as $$
declare
  v_salario numeric(14,2);
  v_benef numeric(14,2);
  v_desc numeric(14,2);
begin
  select cc.salario_base into v_salario
    from rh.colaboradores_cargos cc
   where cc.colaborador_id = p_colaborador_id and cc.deleted_at is null
     and cc.inicio <= p_competencia and (cc.fim is null or cc.fim >= p_competencia)
   order by cc.inicio desc limit 1;
  if v_salario is null then
    raise exception 'Colaborador % sem cargo vigente em %', p_colaborador_id, p_competencia;
  end if;
  select coalesce(sum(b.valor), 0) into v_benef
    from rh.colaboradores_beneficios cb join rh.beneficios b on b.id = cb.beneficio_id
   where cb.colaborador_id = p_colaborador_id and cb.deleted_at is null and b.deleted_at is null
     and cb.inicio <= p_competencia and (cb.fim is null or cb.fim >= p_competencia);
  v_desc := round(v_salario * 0.11, 2);
  return v_salario + v_benef - v_desc;
end $$;

-- Procedure: gera (ou ignora se já existe) a folha de todos os colaboradores com cargo vigente.
create procedure rh.sp_gerar_folha(p_competencia date, inout p_gerados integer default 0)
language plpgsql as $$
declare v_comp date := date_trunc('month', p_competencia)::date;
begin
  insert into rh.folhas_pagamento (colaborador_id, competencia, salario_base, liquido, created_by)
  select cc.colaborador_id, v_comp, cc.salario_base,
         rh.fn_calcular_folha(cc.colaborador_id, v_comp), audit.fn_usuario_atual()
    from rh.colaboradores_cargos cc
   where cc.deleted_at is null and cc.inicio <= v_comp and (cc.fim is null or cc.fim >= v_comp)
  on conflict (colaborador_id, competencia) do nothing;
  get diagnostics p_gerados = row_count;
end $$;

create view rh.vw_folha_resumo as
select competencia, count(*) as colaboradores, sum(salario_base) as total_salarios, sum(liquido) as total_liquido
  from rh.folhas_pagamento where deleted_at is null group by competencia order by competencia desc;
