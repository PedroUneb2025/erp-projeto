-- Particionada por mês (partition by range). PK inclui a chave de partição.
create table rh.registros_ponto (
  id bigint generated always as identity,
  colaborador_id bigint not null references core.colaboradores(id),
  registrado_em timestamptz not null default now(),
  tipo text not null check (tipo in ('entrada','saida')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz,
  primary key (id, registrado_em)
) partition by range (registrado_em);

create table rh.registros_ponto_default partition of rh.registros_ponto default;
select audit.fn_criar_particao_mensal('rh', 'registros_ponto', (date '2026-11-01' + (n || ' month')::interval)::date)
from generate_series(0, 13) n;

-- Horas por mês: pareia cada entrada com a saída seguinte; jornada de referência = 8h/dia.
create view rh.vw_banco_horas as
with pares as (
  select colaborador_id, registrado_em as entrada, tipo,
         lead(tipo) over w as prox_tipo, lead(registrado_em) over w as saida
    from rh.registros_ponto where deleted_at is null
  window w as (partition by colaborador_id order by registrado_em)
), por_dia as (
  select colaborador_id, entrada::date as dia, sum(extract(epoch from saida - entrada)) / 3600 as horas
    from pares where tipo = 'entrada' and prox_tipo = 'saida' group by 1, 2
)
select colaborador_id, date_trunc('month', dia)::date as competencia,
       round(sum(horas)::numeric, 2) as horas_trabalhadas,
       count(*) as dias_trabalhados,
       round((sum(horas) - 8 * count(*))::numeric, 2) as saldo_horas
  from por_dia group by 1, 2;
