create table rh.vagas (
  id bigint generated always as identity primary key,
  titulo text not null check (length(titulo) <= 160),
  cargo_id bigint references rh.cargos(id),
  status text not null default 'aberta' check (status in ('aberta','em_selecao','encerrada')),
  aberta_em date not null default current_date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table rh.candidatos (
  id bigint generated always as identity primary key,
  vaga_id bigint not null references rh.vagas(id),
  nome text not null,
  email text,
  status text not null default 'inscrito' check (status in ('inscrito','entrevista','aprovado','reprovado')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table rh.avaliacoes_desempenho (
  id bigint generated always as identity primary key,
  colaborador_id bigint not null references core.colaboradores(id),
  avaliador_id bigint references core.colaboradores(id),
  periodo text not null,
  nota numeric(4,2) not null check (nota between 0 and 10),
  comentarios text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
