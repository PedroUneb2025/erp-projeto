-- STUB do schema core (responsabilidade da Pessoa A). Substituir pela migração oficial.
-- Contrato assumido pelos módulos: core.clientes, core.fornecedores, core.colaboradores e
-- core.usuarios(id, email, senha_hash, perfil, cliente_id, fornecedor_id, colaborador_id, deleted_at).
create extension if not exists pgcrypto;
create schema core;

create table core.clientes (
  id bigint generated always as identity primary key,
  nome text not null check (length(nome) <= 200),
  documento text,
  email text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table core.fornecedores (
  id bigint generated always as identity primary key,
  nome text not null check (length(nome) <= 200),
  documento text,
  email text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table core.colaboradores (
  id bigint generated always as identity primary key,
  nome text not null check (length(nome) <= 200),
  email text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table core.usuarios (
  id bigint generated always as identity primary key,
  email text not null unique,
  senha_hash text not null,
  perfil text not null check (perfil in ('admin','cliente','fornecedor','colaborador')),
  cliente_id bigint references core.clientes(id),
  fornecedor_id bigint references core.fornecedores(id),
  colaborador_id bigint references core.colaboradores(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
