create schema sd;
create sequence sd.seq_numero_pedido start 1000;

create table sd.pedidos (
  id bigint generated always as identity primary key,
  numero bigint not null unique default nextval('sd.seq_numero_pedido'),
  cliente_id bigint not null references core.clientes(id),
  status text not null default 'rascunho' check (status in ('rascunho','aprovado','faturado','cancelado')),
  total numeric(14,2) not null default 0,
  observacao text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table sd.pedidos_itens (
  id bigint generated always as identity primary key,
  pedido_id bigint not null references sd.pedidos(id),
  descricao text not null,
  quantidade numeric(12,3) not null check (quantidade > 0),
  preco_unitario numeric(14,2) not null check (preco_unitario >= 0),
  subtotal numeric(14,2) generated always as (round(quantidade * preco_unitario, 2)) stored,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);

-- Trigger: recalcula o total do pedido quando os itens mudam.
create function sd.fn_recalcula_total_pedido() returns trigger language plpgsql as $$
declare v_pedido bigint := coalesce(new.pedido_id, old.pedido_id);
begin
  update sd.pedidos
     set total = (select coalesce(sum(subtotal), 0) from sd.pedidos_itens where pedido_id = v_pedido and deleted_at is null)
   where id = v_pedido;
  if tg_op = 'UPDATE' and old.pedido_id <> new.pedido_id then
    update sd.pedidos
       set total = (select coalesce(sum(subtotal), 0) from sd.pedidos_itens where pedido_id = old.pedido_id and deleted_at is null)
     where id = old.pedido_id;
  end if;
  return null;
end $$;
create trigger trg_pedidos_itens_total
  after insert or update or delete on sd.pedidos_itens
  for each row execute function sd.fn_recalcula_total_pedido();

create function sd.fn_total_pedido(p_pedido_id bigint) returns numeric(14,2) language sql stable as $$
  select coalesce(sum(subtotal), 0) from sd.pedidos_itens where pedido_id = p_pedido_id and deleted_at is null
$$;
