create table sd.contratos (
  id bigint generated always as identity primary key,
  cliente_id bigint not null references core.clientes(id),
  objeto text not null,
  valor_mensal numeric(14,2) not null check (valor_mensal >= 0),
  inicio date not null,
  fim date,
  status text not null default 'ativo' check (status in ('ativo','suspenso','encerrado')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table sd.faturas (
  id bigint generated always as identity primary key,
  pedido_id bigint not null references sd.pedidos(id),
  cliente_id bigint not null references core.clientes(id),
  valor numeric(14,2) not null check (valor > 0),
  emitida_em timestamptz not null default now(),
  vencimento date not null,
  status text not null default 'aberta' check (status in ('aberta','paga','vencida','cancelada')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);

-- Procedure: fatura um pedido aprovado e devolve o id da fatura (parâmetro INOUT).
create procedure sd.sp_faturar_pedido(p_pedido_id bigint, inout p_fatura_id bigint default null)
language plpgsql as $$
declare v sd.pedidos%rowtype;
begin
  select * into v from sd.pedidos where id = p_pedido_id and deleted_at is null for update;
  if not found then raise exception 'Pedido % não encontrado', p_pedido_id; end if;
  if v.status <> 'aprovado' then
    raise exception 'Pedido % precisa estar aprovado (status atual: %)', p_pedido_id, v.status;
  end if;
  if v.total <= 0 then raise exception 'Pedido % sem itens/valor', p_pedido_id; end if;
  insert into sd.faturas (pedido_id, cliente_id, valor, vencimento, created_by)
  values (v.id, v.cliente_id, v.total, current_date + 30, audit.fn_usuario_atual())
  returning id into p_fatura_id;
  update sd.pedidos set status = 'faturado' where id = v.id;
end $$;
