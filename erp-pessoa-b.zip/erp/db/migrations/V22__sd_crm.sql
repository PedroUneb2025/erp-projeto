create table sd.etapas_funil (
  id bigint generated always as identity primary key,
  nome text not null,
  ordem smallint not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table sd.oportunidades (
  id bigint generated always as identity primary key,
  cliente_id bigint not null references core.clientes(id),
  etapa_id bigint not null references sd.etapas_funil(id),
  titulo text not null,
  valor_estimado numeric(14,2) not null default 0,
  probabilidade smallint not null default 10 check (probabilidade between 0 and 100),
  responsavel_id bigint references core.colaboradores(id),
  fechamento_previsto date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table sd.interacoes (
  id bigint generated always as identity primary key,
  cliente_id bigint not null references core.clientes(id),
  oportunidade_id bigint references sd.oportunidades(id),
  canal text not null check (canal in ('email','telefone','reuniao','whatsapp')),
  resumo text not null,
  ocorrida_em timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);

create view sd.vw_funil_vendas as
select e.id as etapa_id, e.nome as etapa, e.ordem,
       count(o.id) as oportunidades, coalesce(sum(o.valor_estimado), 0) as valor_total,
       coalesce(sum(o.valor_estimado * o.probabilidade / 100.0), 0)::numeric(14,2) as valor_ponderado
  from sd.etapas_funil e
  left join sd.oportunidades o on o.etapa_id = e.id and o.deleted_at is null
 where e.deleted_at is null
 group by e.id, e.nome, e.ordem order by e.ordem;

create view sd.vw_pedidos_abertos as
select p.id, p.numero, p.status, p.total, c.nome as cliente, p.created_at
  from sd.pedidos p join core.clientes c on c.id = p.cliente_id
 where p.deleted_at is null and p.status in ('rascunho','aprovado');
