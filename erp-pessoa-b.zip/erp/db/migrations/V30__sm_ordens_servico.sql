create schema sm;
create sequence sm.seq_numero_os start 5000;

create table sm.contratos_manutencao (
  id bigint generated always as identity primary key,
  cliente_id bigint not null references core.clientes(id),
  descricao text not null,
  sla_horas integer not null check (sla_horas > 0),
  valor_mensal numeric(14,2) not null default 0,
  inicio date not null,
  fim date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table sm.ordens_servico (
  id bigint generated always as identity primary key,
  numero bigint not null unique default nextval('sm.seq_numero_os'),
  cliente_id bigint not null references core.clientes(id),
  contrato_id bigint references sm.contratos_manutencao(id),
  fornecedor_id bigint references core.fornecedores(id),
  tecnico_id bigint references core.colaboradores(id),
  titulo text not null,
  descricao text,
  prioridade text not null default 'media' check (prioridade in ('baixa','media','alta')),
  status text not null default 'aberta' check (status in ('aberta','em_atendimento','concluida','cancelada')),
  aberta_em timestamptz not null default now(),
  prazo_sla timestamptz,
  concluida_em timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table sm.atendimentos (
  id bigint generated always as identity primary key,
  os_id bigint not null references sm.ordens_servico(id),
  tecnico_id bigint not null references core.colaboradores(id),
  descricao text not null,
  inicio timestamptz not null default now(),
  fim timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);
create table sm.agendamentos (
  id bigint generated always as identity primary key,
  os_id bigint not null references sm.ordens_servico(id),
  tecnico_id bigint not null references core.colaboradores(id),
  inicio timestamptz not null,
  fim timestamptz not null,
  check (fim > inicio),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by bigint,
  deleted_at timestamptz
);

-- Trigger: prazo do SLA = abertura + SLA do contrato (ou padrão por prioridade: 4h/24h/72h).
create function sm.fn_calcula_prazo_sla() returns trigger language plpgsql as $$
begin
  if new.prazo_sla is null then
    new.prazo_sla := new.aberta_em + make_interval(hours => coalesce(
      (select sla_horas from sm.contratos_manutencao where id = new.contrato_id),
      case new.prioridade when 'alta' then 4 when 'media' then 24 else 72 end));
  end if;
  return new;
end $$;
create trigger trg_ordens_servico_sla
  before insert on sm.ordens_servico
  for each row execute function sm.fn_calcula_prazo_sla();

create function sm.fn_sla_estourado(p_os_id bigint) returns boolean language sql stable as $$
  select coalesce(concluida_em, now()) > prazo_sla from sm.ordens_servico where id = p_os_id
$$;

create procedure sm.sp_concluir_os(p_os_id bigint, inout p_estourou boolean default null)
language plpgsql as $$
begin
  update sm.ordens_servico set status = 'concluida', concluida_em = now()
   where id = p_os_id and deleted_at is null and status in ('aberta','em_atendimento');
  if not found then raise exception 'OS % não encontrada ou já finalizada', p_os_id; end if;
  p_estourou := sm.fn_sla_estourado(p_os_id);
end $$;

create view sm.vw_os_em_atraso as
select o.id, o.numero, o.titulo, o.prioridade, o.status, o.prazo_sla,
       round(extract(epoch from now() - o.prazo_sla) / 3600, 1) as horas_atraso, c.nome as cliente
  from sm.ordens_servico o join core.clientes c on c.id = o.cliente_id
 where o.deleted_at is null and o.status in ('aberta','em_atendimento') and now() > o.prazo_sla;

create view sm.vw_agenda_tecnicos as
select a.id, a.inicio, a.fim, t.nome as tecnico, o.numero as os_numero, o.titulo
  from sm.agendamentos a
  join core.colaboradores t on t.id = a.tecnico_id
  join sm.ordens_servico o on o.id = a.os_id
 where a.deleted_at is null and a.fim >= now();
