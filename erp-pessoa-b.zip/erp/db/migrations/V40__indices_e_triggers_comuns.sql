-- Modelo físico: índices B-tree em FKs/filtros, parciais (deleted_at is null) e compostos.
-- rh
create index ix_colaboradores_cargos_colaborador_id on rh.colaboradores_cargos (colaborador_id) where deleted_at is null;
create index ix_colaboradores_cargos_cargo_id on rh.colaboradores_cargos (cargo_id) where deleted_at is null;
create index ix_colaboradores_beneficios_colaborador_id on rh.colaboradores_beneficios (colaborador_id) where deleted_at is null;
create index ix_folhas_pagamento_competencia on rh.folhas_pagamento (competencia) where deleted_at is null;
create index ix_registros_ponto_colaborador_id_registrado_em on rh.registros_ponto (colaborador_id, registrado_em) where deleted_at is null;
create index ix_candidatos_vaga_id on rh.candidatos (vaga_id) where deleted_at is null;
create index ix_avaliacoes_desempenho_colaborador_id on rh.avaliacoes_desempenho (colaborador_id) where deleted_at is null;
-- sd
create index ix_pedidos_cliente_id on sd.pedidos (cliente_id) where deleted_at is null;
create index ix_pedidos_status on sd.pedidos (status) where deleted_at is null;
create index ix_pedidos_itens_pedido_id on sd.pedidos_itens (pedido_id) where deleted_at is null;
create index ix_contratos_cliente_id on sd.contratos (cliente_id) where deleted_at is null;
create index ix_faturas_pedido_id on sd.faturas (pedido_id) where deleted_at is null;
create index ix_faturas_vencimento on sd.faturas (vencimento) where deleted_at is null and status = 'aberta';
create index ix_oportunidades_etapa_id on sd.oportunidades (etapa_id) where deleted_at is null;
create index ix_oportunidades_cliente_id on sd.oportunidades (cliente_id) where deleted_at is null;
create index ix_interacoes_cliente_id_ocorrida_em on sd.interacoes (cliente_id, ocorrida_em desc) where deleted_at is null;
-- sm
create index ix_contratos_manutencao_cliente_id on sm.contratos_manutencao (cliente_id) where deleted_at is null;
create index ix_ordens_servico_cliente_id on sm.ordens_servico (cliente_id) where deleted_at is null;
create index ix_ordens_servico_tecnico_id on sm.ordens_servico (tecnico_id) where deleted_at is null;
create index ix_ordens_servico_fornecedor_id on sm.ordens_servico (fornecedor_id) where deleted_at is null;
create index ix_ordens_servico_prazo_sla on sm.ordens_servico (prazo_sla) where deleted_at is null and status in ('aberta','em_atendimento');
create index ix_atendimentos_os_id on sm.atendimentos (os_id) where deleted_at is null;
create index ix_agendamentos_tecnico_id_inicio on sm.agendamentos (tecnico_id, inicio) where deleted_at is null;
-- auditoria: consulta por tabela/registro (propagado às partições)
create index ix_auditoria_tabela_registro_id on audit.auditoria (tabela, registro_id);

-- trg_<tabela>_updated_at em todas as tabelas de negócio (core, rh, sd, sm) que tenham updated_at.
do $$
declare r record;
begin
  for r in
    select n.nspname as s, c.relname as t
      from pg_class c join pg_namespace n on n.oid = c.relnamespace
     where n.nspname in ('core','rh','sd','sm') and c.relkind in ('r','p') and not c.relispartition
       and exists (select 1 from pg_attribute a where a.attrelid = c.oid and a.attname = 'updated_at' and not a.attisdropped)
  loop
    execute format('create trigger %I before update on %I.%I for each row execute function audit.fn_set_updated_at()',
                   'trg_' || r.t || '_updated_at', r.s, r.t);
  end loop;
end $$;
