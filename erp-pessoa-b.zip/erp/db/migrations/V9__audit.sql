-- Infraestrutura transversal (Pessoa B / modelo físico): auditoria particionada e helpers.
create schema audit;

-- Tabela imutável (append-only): por isso não tem updated_at/deleted_at.
create table audit.auditoria (
  id bigint generated always as identity,
  created_at timestamptz not null default now(),
  created_by bigint,
  tabela text not null,
  registro_id bigint,
  acao text not null,
  dados_antigos jsonb,
  dados_novos jsonb,
  primary key (id, created_at)
) partition by range (created_at);

create table audit.auditoria_default partition of audit.auditoria default;

create function audit.fn_criar_particao_mensal(p_schema text, p_tabela text, p_mes date)
returns void language plpgsql as $$
declare
  v_ini date := date_trunc('month', p_mes)::date;
  v_fim date := (date_trunc('month', p_mes) + interval '1 month')::date;
begin
  execute format('create table if not exists %I.%I partition of %I.%I for values from (%L) to (%L)',
                 p_schema, p_tabela || '_p' || to_char(v_ini, 'YYYYMM'), p_schema, p_tabela, v_ini, v_fim);
end $$;

-- Usuário da aplicação vem de set_config('app.user_id', ..., true) feito pela API.
create function audit.fn_usuario_atual() returns bigint language sql stable as $$
  select nullif(current_setting('app.user_id', true), '')::bigint
$$;

create function audit.fn_set_updated_at() returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- 2026-11 a 2027-12
select audit.fn_criar_particao_mensal('audit', 'auditoria', (date '2026-11-01' + (n || ' month')::interval)::date)
from generate_series(0, 13) n;
