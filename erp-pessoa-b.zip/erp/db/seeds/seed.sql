-- Dados de exemplo (banco recém-migrado; ids partem de 1). Senha de todos os usuários: senha123
-- As linhas de core.* são fictícias e só existem até a Pessoa A entregar o seed oficial.
insert into core.clientes (nome, documento, email) values
  ('Padaria Pão Quente', '12.345.678/0001-90', 'contato@paoquente.example'),
  ('Clínica Vida Plena', '98.765.432/0001-10', 'ti@vidaplena.example');
insert into core.fornecedores (nome, documento, email) values ('TecnoPeças Ltda', '11.222.333/0001-44', 'vendas@tecnopecas.example');
insert into core.colaboradores (nome, email) values
  ('Maria Souza', 'maria@erp.local'), ('Carlos Lima', 'carlos@erp.local'), ('Ana Ribeiro', 'ana@erp.local');
insert into core.usuarios (email, senha_hash, perfil, cliente_id, fornecedor_id, colaborador_id) values
  ('admin@erp.local',      crypt('senha123', gen_salt('bf')), 'admin', null, null, 1),
  ('cliente@erp.local',    crypt('senha123', gen_salt('bf')), 'cliente', 1, null, null),
  ('fornecedor@erp.local', crypt('senha123', gen_salt('bf')), 'fornecedor', null, 1, null),
  ('colab@erp.local',      crypt('senha123', gen_salt('bf')), 'colaborador', null, null, 2);

-- RH
insert into rh.cargos (nome, descricao, salario_base_ref) values
  ('Analista de RH', 'Gestão de pessoas', 4500), ('Técnico de Campo', 'Atendimento técnico', 3200), ('Gerente Comercial', 'Vendas', 9000);
insert into rh.dados_colaboradores (colaborador_id, cpf, data_nascimento, data_admissao) values
  (1, '111.111.111-11', '1990-04-12', '2022-02-01'), (2, '222.222.222-22', '1994-09-30', '2023-06-15'), (3, '333.333.333-33', '1988-01-20', '2021-03-10');
insert into rh.colaboradores_cargos (colaborador_id, cargo_id, salario_base, inicio) values
  (1, 3, 9000, '2022-02-01'), (2, 2, 3200, '2023-06-15'), (3, 1, 4500, '2021-03-10');
insert into rh.beneficios (nome, valor) values ('Vale-refeição', 600), ('Plano de saúde', 350);
insert into rh.colaboradores_beneficios (colaborador_id, beneficio_id, inicio) values (1,1,'2022-02-01'),(2,1,'2023-06-15'),(2,2,'2023-06-15'),(3,1,'2021-03-10');
insert into rh.registros_ponto (colaborador_id, registrado_em, tipo)
select 2, (d::date + h::time)::timestamptz, t
  from generate_series(date '2026-11-02', date '2026-11-06', interval '1 day') d,
       (values ('08:00','entrada'),('12:00','saida'),('13:00','entrada'),('17:30','saida')) v(h, t);
insert into rh.vagas (titulo, cargo_id) values ('Técnico de Campo - Salvador', 2);
insert into rh.candidatos (vaga_id, nome, email) values (1, 'Pedro Alves', 'pedro@example.com'), (1, 'Julia Matos', 'julia@example.com');
insert into rh.avaliacoes_desempenho (colaborador_id, avaliador_id, periodo, nota, comentarios) values (2, 1, '2026-S1', 8.5, 'Boa entrega e pontualidade');
call rh.sp_gerar_folha(date '2026-10-01');

-- SD / CRM
insert into sd.etapas_funil (nome, ordem) values ('Prospecção',1),('Qualificação',2),('Proposta',3),('Negociação',4),('Fechado',5);
insert into sd.oportunidades (cliente_id, etapa_id, titulo, valor_estimado, probabilidade, responsavel_id, fechamento_previsto) values
  (1, 3, 'Renovação do parque de PDVs', 25000, 60, 1, '2026-12-15'),
  (2, 2, 'Sistema de agendamento', 40000, 30, 1, '2027-01-30'),
  (1, 5, 'Manutenção preventiva anual', 12000, 100, 1, '2026-10-30');
insert into sd.pedidos (cliente_id, status, observacao) values (1, 'aprovado', 'Pedido de balanças'), (2, 'rascunho', 'Pedido de tablets');
insert into sd.pedidos_itens (pedido_id, descricao, quantidade, preco_unitario) values
  (1, 'Balança digital 30kg', 3, 850.00), (1, 'Etiquetadora', 1, 420.50), (2, 'Tablet 10"', 5, 1300.00);
insert into sd.contratos (cliente_id, objeto, valor_mensal, inicio) values (1, 'Suporte mensal de PDV', 1800, '2026-01-01');
insert into sd.interacoes (cliente_id, oportunidade_id, canal, resumo) values (1, 1, 'reuniao', 'Apresentação da proposta'), (2, 2, 'email', 'Envio de requisitos');

-- SM
insert into sm.contratos_manutencao (cliente_id, descricao, sla_horas, valor_mensal, inicio) values (1, 'Manutenção PDV - SLA 8h', 8, 1800, '2026-01-01');
insert into sm.ordens_servico (cliente_id, contrato_id, fornecedor_id, tecnico_id, titulo, descricao, prioridade, aberta_em) values
  (1, 1, 1, 2, 'PDV 2 não liga', 'Equipamento sem energia', 'alta', now() - interval '3 days'),
  (1, null, null, 2, 'Troca de etiquetas', null, 'baixa', now()),
  (2, null, null, 2, 'Rede lenta', 'Wi-Fi instável na recepção', 'media', now() - interval '1 hour');
insert into sm.atendimentos (os_id, tecnico_id, descricao) values (1, 2, 'Diagnóstico inicial: fonte queimada');
insert into sm.agendamentos (os_id, tecnico_id, inicio, fim) values (1, 2, now() + interval '1 day', now() + interval '1 day 2 hours');
