# Alta disponibilidade
## Topologia (docker-compose.yml)
`pg-primary` ⇄ (streaming, slot `replica1`) `pg-replica`; **HAProxy**: `:5000` escrita → primário; `:5001` leitura → réplica (primário como *backup*). A API usa `DATABASE_WRITE_URL` (5000) e `DATABASE_READ_URL` (5001); os GETs vão para a réplica.
Verificar: `docker compose exec pg-primary psql -U erp -c "select client_addr, state, sync_state from pg_stat_replication"` e `docker compose exec pg-replica psql -U erp -c "select pg_is_in_recovery()"` (deve ser `t`).

## Backups (serviço `backup`)
| Tipo | Ferramenta | Agenda | Retenção |
|---|---|---|---|
| Lógico | `pg_dump -Fc` | diário 02:00 | 7 dias |
| Físico | `pg_basebackup -Ft -z -X stream` | domingo 03:00 | 21 dias |
Arquivos no volume `backups` (`/backups/logico`, `/backups/fisico`); log em `/backups/backup.log`.

## Teste de restauração
Rodar `scripts/testar_restauracao.sh` (gera dump novo, restaura em `erp_restore` e compara contagens). Passo a passo manual:
1. `docker compose exec backup /usr/local/bin/backup_logico.sh`
2. `docker compose exec pg-primary createdb -U erp erp_restore`
3. `docker compose exec pg-primary pg_restore -U erp -d erp_restore --no-owner /backups/logico/erp_AAAA-MM-DD.dump`
4. Conferir contagens (`select count(*) from ...`) entre `erp` e `erp_restore`.

**Registro da execução (preencher com a saída real):** data: ____ · dump: ____ · tempo de restauração: ____ · tabelas conferidas: ____ · resultado: ____

## RPO e RTO (proposta — validar com o grupo)
| Cenário | RPO | RTO | Como |
|---|---|---|---|
| Queda do primário | ≤ 5 min (replicação assíncrona, lag normalmente < 1 s) | ≤ 15 min | `select pg_promote()` na réplica e apontar `escrita` do HAProxy para ela |
| Erro lógico / dados corrompidos | ≤ 24 h (último `pg_dump`) | ≤ 60 min | restaurar dump em banco limpo |
Limitação: o failover é **manual** (sem Patroni/repmgr) e a leitura na réplica pode estar milissegundos atrás do primário.
