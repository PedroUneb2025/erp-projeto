# Modelo físico
- **Tipos:** dinheiro `numeric(14,2)`; datas com hora `timestamptz`; textos curtos com `check (length(...) <= n)`; PK `bigint generated always as identity`.
- **Colunas padrão:** `created_at`, `updated_at` (trigger `trg_<tabela>_updated_at`), `created_by`, `deleted_at` (exclusão lógica). Exceção: `audit.auditoria` é *append-only* (sem `updated_at`/`deleted_at`).
- **Índices** (`V40`): B-tree nas FKs; compostos para relatórios (`ix_registros_ponto_colaborador_id_registrado_em`, `ix_interacoes_cliente_id_ocorrida_em`, `ix_agendamentos_tecnico_id_inicio`); **parciais** `where deleted_at is null` nas tabelas de negócio; parciais por status (`ix_faturas_vencimento`, `ix_ordens_servico_prazo_sla`).
- **Particionamento por faixa:** `audit.auditoria` (mês, por `created_at`) e `rh.registros_ponto` (mês, por `registrado_em`); partições 2026-11 a 2027-12 + partição `default`. Novas partições: `select audit.fn_criar_particao_mensal('rh','registros_ponto','2028-01-01');` (agendar mensalmente).
- **Pendência com a Pessoa A:** *lançamentos contábeis por ano* pertencem ao módulo financeiro; usar o mesmo padrão (`partition by range (data_lancamento)`, PK incluindo a chave). A função de partição mensal pode ser adaptada para anual.
- **DDL exportado:** `scripts/export_ddl.sh` gera `docs/ddl_modelo_fisico.sql` (precisa do Compose no ar).
