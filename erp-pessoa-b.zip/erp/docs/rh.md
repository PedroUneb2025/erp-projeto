# Módulo RH (`rh`)
Tabelas: `dados_colaboradores`, `cargos`, `colaboradores_cargos`, `beneficios`, `colaboradores_beneficios`, `folhas_pagamento`, `registros_ponto` (particionada por mês), `vagas`, `candidatos`, `avaliacoes_desempenho`.

| Objeto | Nome | Descrição |
|---|---|---|
| Trigger | `trg_colaboradores_cargos_salario` | Grava em `audit.auditoria` toda mudança de `salario_base` |
| Procedure | `rh.sp_gerar_folha(competencia, inout gerados)` | Gera a folha do mês (idempotente) — `POST /api/v1/rh/folha/gerar` |
| Function | `rh.fn_calcular_folha(colaborador, competencia)` | Salário + benefícios − 11% (desconto simplificado) — `GET /api/v1/rh/folha/calcular/{id}` |
| Views | `vw_banco_horas`, `vw_folha_resumo` | `GET /api/v1/rh/views/...` |
| Sequence | `rh.seq_matricula` | Matrícula do colaborador |

CRUD: `/api/v1/rh/<tabela>`. Migrações: `V10`–`V13`. Índices: `V40`.
