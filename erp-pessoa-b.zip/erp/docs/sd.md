# Módulo Vendas e CRM (`sd`)
Tabelas: `pedidos`, `pedidos_itens`, `contratos`, `faturas`, `etapas_funil`, `oportunidades`, `interacoes`.

| Objeto | Nome | Descrição |
|---|---|---|
| Trigger | `trg_pedidos_itens_total` | Recalcula `pedidos.total` ao inserir/alterar/excluir itens |
| Procedure | `sd.sp_faturar_pedido(pedido, inout fatura_id)` | Fatura pedido *aprovado* (vencimento +30d) — `POST /api/v1/sd/pedidos/{id}/faturar` |
| Function | `sd.fn_total_pedido(pedido)` | Soma dos subtotais |
| Views | `vw_funil_vendas`, `vw_pedidos_abertos` | `GET /api/v1/sd/views/...` |
| Sequence | `sd.seq_numero_pedido` | Número do pedido |

Migrações: `V20`–`V22`.
