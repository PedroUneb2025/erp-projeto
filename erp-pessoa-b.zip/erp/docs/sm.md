# Módulo Gestão de Serviços (`sm`)
Tabelas: `contratos_manutencao`, `ordens_servico`, `atendimentos`, `agendamentos`.

| Objeto | Nome | Descrição |
|---|---|---|
| Trigger | `trg_ordens_servico_sla` | Calcula `prazo_sla` na abertura: SLA do contrato ou 4h/24h/72h por prioridade |
| Procedure | `sm.sp_concluir_os(os, inout estourou)` | Conclui a OS e informa se estourou o SLA — `POST /api/v1/sm/ordens_servico/{id}/concluir` |
| Function | `sm.fn_sla_estourado(os)` | `GET /api/v1/sm/ordens_servico/{id}/sla` |
| Views | `vw_os_em_atraso`, `vw_agenda_tecnicos` | `GET /api/v1/sm/views/...` |
| Sequence | `sm.seq_numero_os` | Número da OS |

Migração: `V30`. `ordens_servico.fornecedor_id` alimenta o portal do fornecedor.
