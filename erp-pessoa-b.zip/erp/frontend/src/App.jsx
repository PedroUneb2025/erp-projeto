import { usuario } from "./portais/api.js";
import Login from "./portais/Login.jsx";
import PortalCliente from "./portais/PortalCliente.jsx";
import PortalFornecedor from "./portais/PortalFornecedor.jsx";
import PortalColaborador from "./portais/PortalColaborador.jsx";
import Admin from "./admin/Admin.jsx";

const AREAS = { admin: Admin, cliente: PortalCliente, fornecedor: PortalFornecedor, colaborador: PortalColaborador };

export default function App() {
  const u = usuario();
  if (!u || u.exp * 1000 < Date.now()) return <Login />;
  const Area = AREAS[u.perfil];
  return Area ? <Area /> : <Login />;
}
