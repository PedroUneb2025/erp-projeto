import { useState } from "react";
import { api } from "../portais/api.js";
import { Botao, Erro, Layout, Tabela, useDados } from "../portais/ui.jsx";

const v = (url) => ({ url, leitura: true });
// url = coleção; campos = formulário de criação; acoes = botões (procedures) por linha ou globais
const MODULOS = {
  RH: {
    cargos: { url: "/api/v1/rh/cargos", campos: ["nome", "descricao", "salario_base_ref"] },
    colaboradores_cargos: { url: "/api/v1/rh/colaboradores_cargos", campos: ["colaborador_id", "cargo_id", "salario_base"] },
    beneficios: { url: "/api/v1/rh/beneficios", campos: ["nome", "valor"] },
    folhas_pagamento: { url: "/api/v1/rh/folhas_pagamento", leitura: true,
      global: { rotulo: "Gerar folha (competência AAAA-MM-01)", pede: "competencia", url: (x) => `/api/v1/rh/folha/gerar?competencia=${x}` } },
    vagas: { url: "/api/v1/rh/vagas", campos: ["titulo", "cargo_id"] },
    candidatos: { url: "/api/v1/rh/candidatos", campos: ["vaga_id", "nome", "email"] },
    "vw: folha_resumo": v("/api/v1/rh/views/folha_resumo"),
    "vw: banco_horas": v("/api/v1/rh/views/banco_horas"),
  },
  Vendas: {
    pedidos: { url: "/api/v1/sd/pedidos", campos: ["cliente_id", "status", "observacao"],
      linha: { rotulo: "Faturar", url: (r) => `/api/v1/sd/pedidos/${r.id}/faturar` } },
    pedidos_itens: { url: "/api/v1/sd/pedidos_itens", campos: ["pedido_id", "descricao", "quantidade", "preco_unitario"] },
    contratos: { url: "/api/v1/sd/contratos", campos: ["cliente_id", "objeto", "valor_mensal", "inicio"] },
    oportunidades: { url: "/api/v1/sd/oportunidades", campos: ["cliente_id", "etapa_id", "titulo", "valor_estimado", "probabilidade"] },
    interacoes: { url: "/api/v1/sd/interacoes", campos: ["cliente_id", "canal", "resumo"] },
    "vw: funil_vendas": v("/api/v1/sd/views/funil_vendas"),
  },
  Serviços: {
    ordens_servico: { url: "/api/v1/sm/ordens_servico", campos: ["cliente_id", "titulo", "prioridade", "tecnico_id", "fornecedor_id"],
      linha: { rotulo: "Concluir", url: (r) => `/api/v1/sm/ordens_servico/${r.id}/concluir` } },
    contratos_manutencao: { url: "/api/v1/sm/contratos_manutencao", campos: ["cliente_id", "descricao", "sla_horas", "inicio"] },
    atendimentos: { url: "/api/v1/sm/atendimentos", campos: ["os_id", "tecnico_id", "descricao"] },
    agendamentos: { url: "/api/v1/sm/agendamentos", campos: ["os_id", "tecnico_id", "inicio", "fim"] },
    "vw: os_em_atraso": v("/api/v1/sm/views/os_em_atraso"),
    "vw: agenda_tecnicos": v("/api/v1/sm/views/agenda_tecnicos"),
  },
};

function Recurso({ cfg }) {
  const [n, setN] = useState(0);
  const [form, setForm] = useState({});
  const [msg, setMsg] = useState("");
  const { rows, erro } = useDados(cfg.url, n);
  const rodar = async (fn) => { try { setMsg(JSON.stringify(await fn())); setN(n + 1); } catch (e) { setMsg(e.message); } };

  return (
    <>
      {cfg.campos && (
        <form className="bg-white rounded shadow p-3 mb-3 grid gap-2 sm:grid-cols-3"
          onSubmit={(e) => { e.preventDefault(); rodar(() => api(cfg.url, { method: "POST", body: form })).then(() => setForm({})); }}>
          {cfg.campos.map((c) => (
            <input key={c} className="border rounded px-2 py-1" placeholder={c} value={form[c] ?? ""} onChange={(e) => setForm({ ...form, [c]: e.target.value })} />
          ))}
          <Botao>Criar</Botao>
        </form>
      )}
      {cfg.global && <Botao className="mb-3" onClick={() => { const x = prompt(cfg.global.rotulo); x && rodar(() => api(cfg.global.url(x), { method: "POST" })); }}>{cfg.global.rotulo}</Botao>}
      <Erro msg={erro} />{msg && <p className="text-sm text-slate-600 my-2">{msg}</p>}
      <Tabela rows={rows} acoes={cfg.leitura ? null : (r) => (
        <span className="flex gap-2">
          {cfg.linha && <Botao onClick={() => rodar(() => api(cfg.linha.url(r), { method: "POST" }))}>{cfg.linha.rotulo}</Botao>}
          <Botao className="!bg-red-600" onClick={() => rodar(() => api(`${cfg.url}/${r.id}`, { method: "DELETE" }))}>Excluir</Botao>
        </span>
      )} />
    </>
  );
}

export default function Admin() {
  const [mod, setMod] = useState("RH");
  const [rec, setRec] = useState("cargos");
  const trocar = (m) => { setMod(m); setRec(Object.keys(MODULOS[m])[0]); };
  return (
    <Layout titulo={`Administração · ${mod}`} abas={Object.keys(MODULOS)} aba={mod} setAba={trocar}>
      <div className="flex gap-2 overflow-x-auto mb-3">
        {Object.keys(MODULOS[mod]).map((r) => (
          <button key={r} onClick={() => setRec(r)} className={"text-sm px-2 py-1 rounded whitespace-nowrap " + (r === rec ? "bg-indigo-100 font-medium" : "")}>{r}</button>
        ))}
      </div>
      <Recurso key={mod + rec} cfg={MODULOS[mod][rec]} />
    </Layout>
  );
}
