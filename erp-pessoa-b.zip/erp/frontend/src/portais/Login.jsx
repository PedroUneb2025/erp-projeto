import { useState } from "react";
import { api, setToken } from "./api.js";
import { Botao, Erro } from "./ui.jsx";

export default function Login() {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  async function entrar(e) {
    e.preventDefault();
    try {
      const r = await api("/api/v1/auth/login", { method: "POST", body: { email, senha } });
      setToken(r.access_token);
      location.reload();
    } catch (err) { setErro(err.message); }
  }
  return (
    <form onSubmit={entrar} className="max-w-sm mx-auto mt-16 p-6 bg-white rounded shadow space-y-3">
      <h1 className="text-xl font-semibold">Entrar no ERP</h1>
      <input className="w-full border rounded px-3 py-2" placeholder="E-mail" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input className="w-full border rounded px-3 py-2" type="password" placeholder="Senha" value={senha} onChange={(e) => setSenha(e.target.value)} />
      <Erro msg={erro} />
      <Botao className="w-full py-2">Entrar</Botao>
      <p className="text-xs text-slate-500">O perfil (cliente, fornecedor, colaborador ou admin) define a área exibida.</p>
    </form>
  );
}
