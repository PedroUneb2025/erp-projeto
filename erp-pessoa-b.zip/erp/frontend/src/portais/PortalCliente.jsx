import { useState } from "react";
import { api } from "./api.js";
import { Botao, Erro, Layout, Tabela, useDados } from "./ui.jsx";

export default function PortalCliente() {
  const [aba, setAba] = useState("Pedidos");
  const [n, setN] = useState(0);
  const [f, setF] = useState({ titulo: "", descricao: "", prioridade: "media" });
  const [erro, setErro] = useState("");
  const pedidos = useDados("/api/v1/sd/pedidos");
  const os = useDados("/api/v1/sm/ordens_servico", n);

  async function abrir(e) {
    e.preventDefault();
    try { await api("/api/v1/sm/ordens_servico", { method: "POST", body: f }); setF({ titulo: "", descricao: "", prioridade: "media" }); setN(n + 1); setErro(""); }
    catch (err) { setErro(err.message); }
  }
  return (
    <Layout titulo="Portal do Cliente" abas={["Pedidos", "Ordens de serviço"]} aba={aba} setAba={setAba}>
      {aba === "Pedidos" ? <><Erro msg={pedidos.erro} /><Tabela rows={pedidos.rows} /></> : (
        <>
          <form onSubmit={abrir} className="bg-white rounded shadow p-3 mb-3 grid gap-2 sm:grid-cols-4">
            <input required className="border rounded px-2 py-1 sm:col-span-2" placeholder="Título" value={f.titulo} onChange={(e) => setF({ ...f, titulo: e.target.value })} />
            <select className="border rounded px-2 py-1" value={f.prioridade} onChange={(e) => setF({ ...f, prioridade: e.target.value })}>
              <option value="baixa">baixa</option><option value="media">média</option><option value="alta">alta</option>
            </select>
            <Botao>Abrir OS</Botao>
            <textarea className="border rounded px-2 py-1 sm:col-span-4" placeholder="Descrição" value={f.descricao} onChange={(e) => setF({ ...f, descricao: e.target.value })} />
          </form>
          <Erro msg={erro || os.erro} /><Tabela rows={os.rows} />
        </>
      )}
    </Layout>
  );
}
