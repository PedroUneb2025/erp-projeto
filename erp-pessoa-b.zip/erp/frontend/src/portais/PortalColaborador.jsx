import { useState } from "react";
import { api } from "./api.js";
import { Botao, Erro, Layout, Tabela, useDados } from "./ui.jsx";

export default function PortalColaborador() {
  const [aba, setAba] = useState("Ponto");
  const [n, setN] = useState(0);
  const [erro, setErro] = useState("");
  const ponto = useDados("/api/v1/rh/registros_ponto?limite=30", n);
  const folha = useDados("/api/v1/rh/folhas_pagamento");
  const banco = useDados("/api/v1/rh/views/banco_horas");

  async function bater(tipo) {
    try { await api("/api/v1/rh/registros_ponto", { method: "POST", body: { tipo } }); setN(n + 1); setErro(""); }
    catch (e) { setErro(e.message); }
  }
  return (
    <Layout titulo="Portal do Colaborador" abas={["Ponto", "Contracheque"]} aba={aba} setAba={setAba}>
      {aba === "Ponto" ? (
        <>
          <div className="flex gap-2 mb-3"><Botao onClick={() => bater("entrada")}>Registrar entrada</Botao><Botao onClick={() => bater("saida")}>Registrar saída</Botao></div>
          <Erro msg={erro || ponto.erro} />
          <h2 className="font-medium my-2">Banco de horas</h2><Tabela rows={banco.rows} />
          <h2 className="font-medium my-2">Últimos registros</h2><Tabela rows={ponto.rows} />
        </>
      ) : <><Erro msg={folha.erro} /><Tabela rows={folha.rows} /></>}
    </Layout>
  );
}
