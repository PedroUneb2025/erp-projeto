import { useState } from "react";
import { Erro, Layout, Tabela, useDados } from "./ui.jsx";

export default function PortalFornecedor() {
  const [aba, setAba] = useState("Ordens atribuídas");
  const os = useDados("/api/v1/sm/ordens_servico");
  return (
    <Layout titulo="Portal do Fornecedor" abas={["Ordens atribuídas"]} aba={aba} setAba={setAba}>
      <Erro msg={os.erro} /><Tabela rows={os.rows} />
    </Layout>
  );
}
