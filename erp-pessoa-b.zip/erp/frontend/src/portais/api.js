// Toda a comunicação passa pela API dos módulos (/api/v1/...). O front nunca acessa o banco.
let token = localStorage.getItem("token");

export function setToken(t) {
  token = t;
  t ? localStorage.setItem("token", t) : localStorage.removeItem("token");
}

export function usuario() {
  try { return token ? JSON.parse(atob(token.split(".")[1])) : null; } catch { return null; }
}

export async function api(path, { method = "GET", body } = {}) {
  const r = await fetch(path, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || r.statusText);
  return r.status === 204 ? null : r.json();
}
