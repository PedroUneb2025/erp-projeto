import { useEffect, useState } from "react";
import { api, setToken } from "./api.js";

const OCULTAS = ["created_by", "updated_at", "deleted_at"];

export function Layout({ titulo, abas, aba, setAba, children }) {
  return (
    <div className="min-h-screen">
      <header className="bg-indigo-700 text-white px-4 py-3 flex items-center justify-between">
        <h1 className="font-semibold">{titulo}</h1>
        <button className="text-sm underline" onClick={() => { setToken(null); location.reload(); }}>Sair</button>
      </header>
      <nav className="flex gap-2 overflow-x-auto px-3 py-2 bg-white border-b">
        {abas.map((a) => (
          <button key={a} onClick={() => setAba(a)}
            className={"px-3 py-1 rounded-full text-sm whitespace-nowrap " + (a === aba ? "bg-indigo-600 text-white" : "bg-slate-100")}>
            {a}
          </button>
        ))}
      </nav>
      <main className="max-w-5xl mx-auto p-3">{children}</main>
    </div>
  );
}

export function useDados(url, dep = 0) {
  const [rows, setRows] = useState([]);
  const [erro, setErro] = useState("");
  useEffect(() => { api(url).then(setRows).catch((e) => setErro(e.message)); }, [url, dep]);
  return { rows, erro };
}

export function Tabela({ rows, acoes }) {
  if (!rows.length) return <p className="text-slate-500 text-sm">Nada por aqui ainda.</p>;
  const cols = Object.keys(rows[0]).filter((c) => !OCULTAS.includes(c));
  return (
    <div className="overflow-x-auto bg-white rounded shadow">
      <table className="min-w-full text-sm">
        <thead className="bg-slate-100"><tr>{cols.map((c) => <th key={c} className="text-left px-3 py-2">{c}</th>)}{acoes && <th />}</tr></thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={r.id ?? i} className="border-t">
              {cols.map((c) => <td key={c} className="px-3 py-2">{String(r[c] ?? "")}</td>)}
              {acoes && <td className="px-3 py-2 whitespace-nowrap">{acoes(r)}</td>}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export const Erro = ({ msg }) => (msg ? <p className="text-red-600 text-sm my-2">{msg}</p> : null);
export const Botao = (p) => <button {...p} className={"bg-indigo-600 text-white rounded px-3 py-1 text-sm " + (p.className || "")} />;
