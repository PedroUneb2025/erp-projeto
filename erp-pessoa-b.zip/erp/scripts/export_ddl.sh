#!/bin/bash
# Exporta o DDL do modelo físico (tipos, índices, partições) para a documentação.
docker compose exec -T pg-primary pg_dump -U erp -d erp --schema-only --no-owner > docs/ddl_modelo_fisico.sql
echo "Gerado docs/ddl_modelo_fisico.sql"
