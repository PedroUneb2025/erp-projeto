#!/bin/bash
# Restaura o último pg_dump num banco limpo (erp_restore) e compara contagens com o banco original.
set -e
ULTIMO=$(docker compose exec -T backup sh -c 'ls -t /backups/logico/*.dump | head -1' | tr -d '\r')
echo "Dump: $ULTIMO"
docker compose exec -T backup sh -c '/usr/local/bin/backup_logico.sh' >/dev/null   # garante um dump recente
ULTIMO=$(docker compose exec -T backup sh -c 'ls -t /backups/logico/*.dump | head -1' | tr -d '\r')
docker compose exec -T pg-primary sh -c "dropdb -U erp --if-exists erp_restore && createdb -U erp erp_restore"
docker compose exec -T pg-primary pg_restore -U erp -d erp_restore --no-owner "$ULTIMO"
for t in core.clientes rh.folhas_pagamento rh.registros_ponto sd.pedidos sm.ordens_servico audit.auditoria; do
  a=$(docker compose exec -T pg-primary psql -U erp -d erp -Atc "select count(*) from $t")
  b=$(docker compose exec -T pg-primary psql -U erp -d erp_restore -Atc "select count(*) from $t")
  echo "$t original=$a restaurado=$b $([ "$a" = "$b" ] && echo OK || echo DIVERGE)"
done
