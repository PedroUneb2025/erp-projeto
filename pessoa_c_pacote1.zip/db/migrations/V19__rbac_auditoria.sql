-- V19: roles (RBAC), pgcrypto e auditoria generica (Pessoa C)
-- Se a Pessoa A ja criou as roles na V1, remova a secao 1 antes de enviar.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 1) Roles de cargo (sem login; usuarios reais herdam via GRANT role_x TO ...)
DO $$
DECLARE r text;
BEGIN
  FOREACH r IN ARRAY ARRAY['role_ceo','role_dba','role_diretor','role_gerente','role_supervisor','role_operador'] LOOP
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
      EXECUTE format('CREATE ROLE %I NOLOGIN', r);
    END IF;
  END LOOP;
END $$;

-- 2) Auditoria
CREATE SCHEMA IF NOT EXISTS audit;

CREATE TABLE audit.log_auditoria (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tabela text NOT NULL,
  operacao text NOT NULL CHECK (operacao IN ('INSERT','UPDATE','DELETE')),
  usuario text NOT NULL DEFAULT current_user,
  dados_antes jsonb,
  dados_depois jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ix_log_auditoria_tabela ON audit.log_auditoria (tabela);
CREATE INDEX ix_log_auditoria_created_at ON audit.log_auditoria (created_at);

-- Trigger generica: anexe com
--   CREATE TRIGGER trg_<tabela>_auditoria AFTER INSERT OR UPDATE OR DELETE
--   ON <schema>.<tabela> FOR EACH ROW EXECUTE FUNCTION audit.fn_auditar();
CREATE FUNCTION audit.fn_auditar() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = audit, pg_temp AS $$
BEGIN
  INSERT INTO audit.log_auditoria (tabela, operacao, usuario, dados_antes, dados_depois)
  VALUES (TG_TABLE_SCHEMA || '.' || TG_TABLE_NAME, TG_OP, session_user,
          CASE WHEN TG_OP IN ('UPDATE','DELETE') THEN to_jsonb(OLD) END,
          CASE WHEN TG_OP IN ('INSERT','UPDATE') THEN to_jsonb(NEW) END);
  RETURN COALESCE(NEW, OLD);
END $$;

-- Trigger generica de updated_at
CREATE FUNCTION audit.fn_set_updated_at() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END $$;

-- 3) Permissoes: so CEO e DBA leem a auditoria
REVOKE ALL ON SCHEMA audit FROM PUBLIC;
GRANT USAGE ON SCHEMA audit TO role_ceo, role_dba, role_diretor, role_gerente, role_supervisor, role_operador;
GRANT SELECT ON audit.log_auditoria TO role_ceo, role_dba;
GRANT EXECUTE ON FUNCTION audit.fn_auditar(), audit.fn_set_updated_at() TO PUBLIC;
