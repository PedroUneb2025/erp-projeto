-- V20: MM - materiais, requisicao e pedido de compra
-- ATENCAO: core.fornecedores e core.colaboradores (Pessoa A) precisam existir com PK id.
CREATE SCHEMA IF NOT EXISTS mm;
CREATE SEQUENCE mm.seq_numero_pedido_compra START 1000;

CREATE TABLE mm.materiais (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  codigo text NOT NULL UNIQUE,
  descricao text NOT NULL,
  unidade_medida text NOT NULL,
  estoque_minimo numeric(14,3) NOT NULL DEFAULT 0 CHECK (estoque_minimo >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by bigint,
  deleted_at timestamptz
);

CREATE TABLE mm.requisicoes_compra (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  material_id bigint NOT NULL REFERENCES mm.materiais(id),
  solicitante_id bigint NOT NULL REFERENCES core.colaboradores(id),
  quantidade numeric(14,3) NOT NULL CHECK (quantidade > 0),
  status text NOT NULL DEFAULT 'PENDENTE' CHECK (status IN ('PENDENTE','APROVADA','REJEITADA','ATENDIDA')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by bigint,
  deleted_at timestamptz
);

CREATE TABLE mm.pedidos_compra (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  numero text NOT NULL UNIQUE DEFAULT ('PC-' || nextval('mm.seq_numero_pedido_compra')::text),
  fornecedor_id bigint NOT NULL REFERENCES core.fornecedores(id),
  status text NOT NULL DEFAULT 'ABERTO' CHECK (status IN ('ABERTO','RECEBIDO','CANCELADO')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by bigint,
  deleted_at timestamptz
);

CREATE TABLE mm.itens_pedido_compra (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  pedido_compra_id bigint NOT NULL REFERENCES mm.pedidos_compra(id),
  material_id bigint NOT NULL REFERENCES mm.materiais(id),
  quantidade numeric(14,3) NOT NULL CHECK (quantidade > 0),
  preco_unitario numeric(14,2) NOT NULL CHECK (preco_unitario >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by bigint,
  deleted_at timestamptz
);

CREATE INDEX ix_requisicoes_compra_material_id ON mm.requisicoes_compra (material_id);
CREATE INDEX ix_pedidos_compra_fornecedor_id ON mm.pedidos_compra (fornecedor_id);
CREATE INDEX ix_itens_pedido_compra_pedido_compra_id ON mm.itens_pedido_compra (pedido_compra_id);
CREATE INDEX ix_itens_pedido_compra_material_id ON mm.itens_pedido_compra (material_id);

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['materiais','requisicoes_compra','pedidos_compra','itens_pedido_compra'] LOOP
    EXECUTE format('CREATE TRIGGER trg_%1$s_updated_at BEFORE UPDATE ON mm.%1$I FOR EACH ROW EXECUTE FUNCTION audit.fn_set_updated_at()', t);
    EXECUTE format('CREATE TRIGGER trg_%1$s_auditoria AFTER INSERT OR UPDATE OR DELETE ON mm.%1$I FOR EACH ROW EXECUTE FUNCTION audit.fn_auditar()', t);
  END LOOP;
END $$;

-- Permissoes MM (matriz: ver docs/matriz_permissoes.md)
GRANT USAGE ON SCHEMA mm TO role_ceo, role_dba, role_diretor, role_gerente, role_supervisor, role_operador;
GRANT ALL ON ALL TABLES IN SCHEMA mm TO role_ceo, role_dba;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA mm TO role_diretor, role_gerente, role_supervisor;
GRANT SELECT ON ALL TABLES IN SCHEMA mm TO role_operador;
GRANT SELECT, INSERT ON mm.requisicoes_compra TO role_operador;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA mm TO role_ceo, role_dba, role_diretor, role_gerente, role_supervisor, role_operador;
