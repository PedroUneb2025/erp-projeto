-- V21: MM - estoque, movimentacao, trigger, procedure, function e views
CREATE TABLE mm.depositos (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  nome text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by bigint,
  deleted_at timestamptz
);

CREATE TABLE mm.saldos_estoque (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  material_id bigint NOT NULL REFERENCES mm.materiais(id),
  deposito_id bigint NOT NULL REFERENCES mm.depositos(id),
  quantidade numeric(14,3) NOT NULL DEFAULT 0 CHECK (quantidade >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by bigint,
  deleted_at timestamptz,
  UNIQUE (material_id, deposito_id)
);

CREATE TABLE mm.movimentacoes_estoque (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  material_id bigint NOT NULL REFERENCES mm.materiais(id),
  deposito_id bigint NOT NULL REFERENCES mm.depositos(id),
  tipo text NOT NULL CHECK (tipo IN ('ENTRADA','SAIDA')),
  quantidade numeric(14,3) NOT NULL CHECK (quantidade > 0),
  pedido_compra_id bigint REFERENCES mm.pedidos_compra(id),
  observacao text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by bigint,
  deleted_at timestamptz
);

CREATE INDEX ix_saldos_estoque_material_id ON mm.saldos_estoque (material_id);
CREATE INDEX ix_movimentacoes_estoque_material_id ON mm.movimentacoes_estoque (material_id);
CREATE INDEX ix_movimentacoes_estoque_created_at ON mm.movimentacoes_estoque (created_at);

-- Trigger: atualiza o saldo a cada entrada/saida (saida alem do saldo viola o CHECK >= 0)
CREATE FUNCTION mm.fn_atualizar_saldo() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = mm, pg_temp AS $$
DECLARE v_delta numeric;
BEGIN
  v_delta := CASE NEW.tipo WHEN 'ENTRADA' THEN NEW.quantidade ELSE -NEW.quantidade END;
  INSERT INTO mm.saldos_estoque (material_id, deposito_id, quantidade)
  VALUES (NEW.material_id, NEW.deposito_id, v_delta)
  ON CONFLICT (material_id, deposito_id)
  DO UPDATE SET quantidade = mm.saldos_estoque.quantidade + EXCLUDED.quantidade;
  RETURN NEW;
END $$;

CREATE TRIGGER trg_movimentacoes_estoque_saldo
AFTER INSERT ON mm.movimentacoes_estoque
FOR EACH ROW EXECUTE FUNCTION mm.fn_atualizar_saldo();

-- Function: saldo total de um material
CREATE FUNCTION mm.fn_saldo_material(p_material_id bigint) RETURNS numeric
LANGUAGE sql STABLE AS $$
  SELECT COALESCE(SUM(quantidade), 0) FROM mm.saldos_estoque WHERE material_id = p_material_id;
$$;

-- Procedure: registra entrada de mercadoria (e marca o pedido como recebido)
CREATE PROCEDURE mm.sp_registrar_entrada_mercadoria(
  p_material_id bigint, p_deposito_id bigint, p_quantidade numeric,
  p_pedido_compra_id bigint DEFAULT NULL, p_usuario_id bigint DEFAULT NULL)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = mm, pg_temp AS $$
BEGIN
  IF p_quantidade IS NULL OR p_quantidade <= 0 THEN
    RAISE EXCEPTION 'Quantidade deve ser maior que zero';
  END IF;
  INSERT INTO mm.movimentacoes_estoque (material_id, deposito_id, tipo, quantidade, pedido_compra_id, created_by)
  VALUES (p_material_id, p_deposito_id, 'ENTRADA', p_quantidade, p_pedido_compra_id, p_usuario_id);
  IF p_pedido_compra_id IS NOT NULL THEN
    UPDATE mm.pedidos_compra SET status = 'RECEBIDO' WHERE id = p_pedido_compra_id AND status = 'ABERTO';
  END IF;
END $$;

-- Views
CREATE VIEW mm.vw_estoque_minimo AS
SELECT m.id AS material_id, m.codigo, m.descricao, m.estoque_minimo,
       mm.fn_saldo_material(m.id) AS saldo_atual
FROM mm.materiais m
WHERE m.deleted_at IS NULL AND mm.fn_saldo_material(m.id) < m.estoque_minimo;

CREATE VIEW mm.vw_saldo_por_deposito AS
SELECT s.deposito_id, d.nome AS deposito, m.codigo, m.descricao, s.quantidade
FROM mm.saldos_estoque s
JOIN mm.depositos d ON d.id = s.deposito_id
JOIN mm.materiais m ON m.id = s.material_id
WHERE s.deleted_at IS NULL;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['depositos','saldos_estoque','movimentacoes_estoque'] LOOP
    EXECUTE format('CREATE TRIGGER trg_%1$s_updated_at BEFORE UPDATE ON mm.%1$I FOR EACH ROW EXECUTE FUNCTION audit.fn_set_updated_at()', t);
    EXECUTE format('CREATE TRIGGER trg_%1$s_auditoria AFTER INSERT OR UPDATE OR DELETE ON mm.%1$I FOR EACH ROW EXECUTE FUNCTION audit.fn_auditar()', t);
  END LOOP;
END $$;

GRANT ALL ON ALL TABLES IN SCHEMA mm TO role_ceo, role_dba;
GRANT SELECT, INSERT, UPDATE ON mm.depositos, mm.saldos_estoque, mm.movimentacoes_estoque TO role_diretor, role_gerente, role_supervisor;
GRANT SELECT ON mm.depositos, mm.saldos_estoque, mm.movimentacoes_estoque TO role_operador;
GRANT INSERT ON mm.movimentacoes_estoque TO role_operador;
GRANT SELECT ON mm.vw_estoque_minimo, mm.vw_saldo_por_deposito TO role_diretor, role_gerente, role_supervisor, role_operador;
REVOKE ALL ON PROCEDURE mm.sp_registrar_entrada_mercadoria(bigint,bigint,numeric,bigint,bigint) FROM PUBLIC;
GRANT EXECUTE ON PROCEDURE mm.sp_registrar_entrada_mercadoria(bigint,bigint,numeric,bigint,bigint)
  TO role_ceo, role_dba, role_diretor, role_gerente, role_supervisor, role_operador;
