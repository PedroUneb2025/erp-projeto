# Matriz de permissões (cargo × schema)

| Cargo | mm | audit | Observação |
|---|---|---|---|
| role_ceo | tudo | leitura | acesso total |
| role_dba | tudo | leitura | acesso total |
| role_diretor | leitura/escrita | sem acesso | sem DELETE |
| role_gerente | leitura/escrita | sem acesso | sem DELETE |
| role_supervisor | leitura/escrita | sem acesso | sem DELETE |
| role_operador | leitura; insere requisições e movimentações | sem acesso | uso diário |

Atualize as colunas pp, qm e ps nas próximas migrações.
