#!/usr/bin/env bash
# Rode na raiz do clone de erp-projeto, com esta pasta copiada por cima.
set -e
git checkout main && git pull
git checkout -b feat/c-rbac-auditoria-mm
git add db/migrations/V19__rbac_auditoria.sql
git commit -m "feat(sys): cria roles, pgcrypto e audit.log_auditoria"
git add db/migrations/V20__mm_materiais.sql
git commit -m "feat(mm): tabelas de materiais e compras"
git add db/migrations/V21__mm_estoque.sql
git commit -m "feat(mm): estoque, trigger, procedure e views"
git add docs/matriz_permissoes.md
git commit -m "docs(sys): matriz de permissoes cargo x schema"
git push -u origin feat/c-rbac-auditoria-mm
echo "Agora abra o Pull Request no GitHub e peca 1 revisao."
